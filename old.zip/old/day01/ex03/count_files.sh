find . -type f -print -or -type d -print | wc -l | tr -d ' '
