ifconfig | grep "ether " | sed -e "s/ether//" | cut -c3-
