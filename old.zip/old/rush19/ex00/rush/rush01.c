/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mskiles <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/21 16:26:49 by mskiles           #+#    #+#             */
/*   Updated: 2018/11/04 18:32:24 by mskiles          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../header/ft_list.h"

char	*create_array01(char first, char middle, char end)
{
	char	*a;

	a = malloc(3);
	a[0] = first;
	a[1] = middle;
	a[2] = end;
	return (a);
}

char	*rush01(int x, int y)
{
	char	*line;
	int		size;
	int		i;

	size = (x + 1) * y + 1;
	line = malloc(sizeof(char) * size);
	i = -1;
	while (size > ++i)
		line[i] = '\0';
	if (y == 1)
		line = add_to_line(line, x, create_array01('/', '*', '\\'));
	else if (y > 0)
	{
		line = add_to_line(line, x, create_array01('/', '*', '\\'));
		while (y > 2)
		{
			line = add_to_line(line, x, create_array01('*', ' ', '*'));
			y--;
		}
		line = add_to_line(line, x, create_array01('\\', '*', '/'));
	}
	return (line);
}
