/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colee_2.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mskiles <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/04 03:23:05 by mskiles           #+#    #+#             */
/*   Updated: 2018/11/04 17:14:23 by mskiles          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../header/ft_list.h"

int     find_cols(char *s)
{
    int i;
    
    i = 0;
    while (s[i] != '\n')
        i++;
    return (i);
}

int     find_rows(char *s)
{
    int i;
    int row;
    
    i = 0;
    row = 0;
    while (s[i])
    {
        if (s[i] == '\n')
            row++;
        i++;
    }
    return (row);
}

void	compare(char *s)
{
//    printf("%s\n", s);
    printf("cols = %d\nrows = %d\n", find_cols(s), find_rows(s));
    printf("%s\n", rush00(find_cols(s), find_rows(s)));
    
//    if (is_valid(s) == 1)
//        ft_putstr("aucune\n");
//    else
//        ft_putstr("OK");
}
