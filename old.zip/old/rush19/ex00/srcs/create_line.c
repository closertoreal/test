/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   create_line.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mskiles <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/04 16:31:30 by mskiles           #+#    #+#             */
/*   Updated: 2018/11/04 18:07:00 by mskiles          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../header/ft_list.h"

char	*add_to_line(char *line, int x, char *chars)
{
	int i;

	i = 0;
	while (line[i])
		i++;
	if (x > 0)
	{
		if (x == 1)
			line[i++] = chars[0];
		else if (x > 1)
		{
			line[i++] = chars[0];
			while (x > 2)
			{
				line[i++] = chars[1];
				x--;
			}
			line[i++] = chars[2];
		}
		line[i] = '\n';
	}
	return (line);
}
