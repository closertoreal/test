/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   strrev.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/06 15:18:13 by hbennard          #+#    #+#             */
/*   Updated: 2018/11/06 15:19:50 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int        ft_strlen(char *str)
{
	    int        i;

		    i = 0;
			    while (str[i])
					        i++;
				    return (i);
}

char    *ft_strrev(char *str)
{
	    int     i;
		int     length;
		char    buff;

				    i = 0;
					length = ft_strlen(str);
					while (length - 1 > i)
						{
						buff = str[i];
						str[i] = str[length - 1];
						str[length - 1] = buff;
						length--;
						i++;
						}
return (str);
}

int main(int argc, char **argv)
{
	if (argc == 2)
		printf("%s", ft_strrev(argv[1]));
	else
		return (0);
}





/*
 char str[] = "string reverse";
printf("%s", ft_strrev(str));
return 0;\
 */
