#include <stdio.h>

int	is_power_of_2(unsigned int n)
{
	int swap;
	swap = n;
	
	if (swap/2 == 1)
		return (1);
	if (swap/2 != 1)
		is_power_of_2(swap/2);
	if (swap/2 < 1)
		return (0);
	return (0);
}

int main()
{
	unsigned int n;
	n = 256;
	printf("%d", is_power_of_2(n));
	return (0);
}
