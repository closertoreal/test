#include <unistd.h>

void maff_revalpha()
{
	write(1, "zYxWvUtSrQpOnMlKjIhGfEdCbA\n", 27);
}

int main()
{
	maff_revalpha();
	return(0);
}
