#include <unistd.h>
#include <stdio.h>

int        ft_strlen(char *str)
{
	int        i;
	
	i = 0;
	while (str[i])
		i++;
	return (i);
}

void ft_putchar(char c)
{
	write(1, &c, 1);
}

int rev_print(char **argv)
{
	int len;
	int i;

	int j;
	j = 0;
	i = 0;
	
	while (argv[1][j])
		j++;
	len = j;
	
	
	while (len >= 0)
	{
		ft_putchar(argv[1][len]);
		len--;
		
	}
	return (0);
}

int main (int argc, char **argv)
{
	if (argc != 2)
		ft_putchar('\n');
	else
		rev_print(argv);
	return (0);
}
