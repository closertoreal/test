
#include <stdio.h>
#include <stdlib.h>

int ft_do_op(char **argv)
{
	if (*argv[2] == '+')
		printf("%d", atoi(argv[1]) + atoi(argv[3]));
	else if (*argv[2] == '-')
		printf("%d", atoi(argv[1]) - atoi(argv[3]));
	else if (*argv[2] == '*')
		printf("%d", atoi(argv[1]) * atoi(argv[3]));
	else if (*argv[2] == '/')
		printf("%d", atoi(argv[1]) / atoi(argv[3]));
	printf("\n");
	return (0);
}

int main (int argc, char **argv)
{
	if (argc != 4)
		printf("\n");
	else
		ft_do_op(argv);
	return (0);
	
}
