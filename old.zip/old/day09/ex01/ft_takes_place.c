/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_takes_place.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/25 17:47:46 by hbennard          #+#    #+#             */
/*   Updated: 2018/10/25 18:02:29 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_takes_place(int hour)
{
	int low;
	int high;

	if (hour <= 0 && hour < 12)
	{
		low = hour - 1;
		high = hour + 1;
		printf("THE FOLLOWING TAKES PLACE BETWEEN %d A.M. AND %d A.M.", low, high);
	}
	if (hour <= 12 && hour <= 24)
		    {
				low = hour - 13;
				high = hour - 11;
				printf("THE FOLLOWING TAKES PLACE BETWEEN %d P.M. AND %d P.M.", low, high);
			}
}
