/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/21 21:58:19 by hbennard          #+#    #+#             */
/*   Updated: 2018/10/21 22:13:36 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int ft_putchar(char c);

void	rush(int x, int y)
{
	int i;
	int j;
	
	i = 0;
	if (x < 0 || y < 0)
	while (++j <= x)
		{
            j = 0;
			if ((j == 1 || j == x) && (i == 1 || i == y))
				ft_putchar('o');
			else if (j == 1 || j == x)
				ft_putchar('|');
			else if (i <= y)
				ft_putchar('-');
			else
				ft_putchar(' ');
		}
	ft_putchar('\n');
}



