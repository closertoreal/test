/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/20 14:23:54 by hbennard          #+#    #+#             */
/*   Updated: 2018/10/20 14:23:56 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>

void rush( int x, int y)
{
    int i,j;
    i = 0;
    while(++i <= y)
    {
     j = 0;
        while(++j <= x)
            {
            if (j == 1 && (i == 1 || i == y))
                putchar('A');
            else if (j == x && (i == 1 || i == y))
                putchar('C');
            else if (i == 1 || i == y || j == 1 || j == x)
                putchar('B');
            else
                putchar (' ');
            }
            putchar('\n');
        }
}
int main()
{
    int x,y;
    write(1, "Enter length: \n", 14);
    scanf("%d", &x);
    write(1, "Enter width: ", 14);
    scanf("%d", &y);
    rush(x,y);
    return 0;
}


/*
 if (j == 1 && (i == 1 || i == y))
 putchar('A');
 if (j == x && (i == 1 || i == y))
 putchar('C');
 if ((i == 1 && j > 1 && j < x) || (i == y && j > 1 && j < x) || (j == 1 && (i == 2 || i < y)) || (j == x && (i > 1 || i < y)))                                    putchar('B');
 else
 putchar(' ');
 */
