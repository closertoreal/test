/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sudoku.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ujyzene <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/27 13:08:45 by ujyzene           #+#    #+#             */
/*   Updated: 2018/10/27 20:45:56 by ujyzene          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#define N 9
#define TRUE 1
#define FALSE 0
typedef int t_bool;

void print_field(char **sdk);
t_bool in_row_valid(char **grid, int row, char value);
t_bool in_col_valid(char **grid, int col, char value);
t_bool in_box_valid(char **grid, int start_row, int start_col, char value);
t_bool solve(char **grid);
t_bool is_sloved(char **grid);

int main(int argc, char **argv)
{
	char **grid;
	int i;

	grid = (char**)malloc(sizeof(char*) * N);
	if (argc == N + 1)
	{
		i = 0;
		while (i < N)
		{
			grid[i] = argv[i + 1];
			i++;
		}
	}
	solve(grid);
	return (0);
}

t_bool solve(char **grid)
{
	int row;
	int col;
	char value;

	if (is_sloved(grid))
		return (TRUE);
//TODO
//Нужно каждый раз этот цикл откатывать
//Т.Е. если ни один вариант не подходит нужно сделать шаг назад ( или найти первый с начала [0,0] неопределенный элемент (.) 
	row = 0;
	while (row < N)
	{
		col = 0;
		while (col < N)
		{
			if (grid[row][col] == '.')
			{
				value = '1';
				while (value <= '9')
				{
					if (in_row_valid(grid, row, value) &&
						in_col_valid(grid, col, value) &&
						in_box_valid(grid, row - (row % 3), col - (col % 3), value))
					{
							grid[row][col] = value;
							printf("grid[%d][%d] = %c\n", row, col, value);
							if (solve(grid))
								return (TRUE);

							grid[row][col] = '.';		
					}
					value++;
				}
			}
			col++;
		}
		row++;
	}
	return (FALSE);
}
void print_field(char **grid)
{
	int row;
	int col;

	row = 0;
	while (row < N)
	{
		col = 0;
		while (col < N)
		{
			write(1, &grid[row][col], 1);
			write(1, "\t", 1);
			col++;
		}
		write(1, "\n", 1);
		row++;
	}
}

t_bool in_row_valid(char **grid, int row, char value)
{
	int i;

	i = 0;
	while (i < N)
		if (grid[row][i++] == value)
			return (FALSE);
	return (TRUE);
}

t_bool in_col_valid(char **grid, int col, char value)
{
	int i;

	i = 0;
	while (i < N)
		if (grid[i++][col] == value)
			return (FALSE);
	return (TRUE);
}

t_bool in_box_valid(char **grid, int start_row, int start_col, char value)
{
	int i;
	int j;

	i = 0;
	while (i < 3)
	{
		j = 0;
		while (j < 3)
			if (grid[start_row + i++][start_col + j++] == value)
				return (FALSE);
	}
	return (TRUE);
}

t_bool is_sloved(char **grid)
{
	int i;
	int j;

	i = 0;
	j = 0;
	while (i < N)
	{
		while (j < N)
		{
			if (grid[i][j] == '.')
				return (FALSE);
			j++;
		}
		i++;
	}
	return (TRUE);
}	
