/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sudokuvim.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/28 16:51:36 by hbennard          #+#    #+#             */
/*   Updated: 2018/10/28 17:00:02 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_check(char **puzzle, char c, int row, int column)
{
	int		k;
	int		rs;
	int		cs;

	k = 0;
	rs = (((row - 1) / 3) * 3) + 1;
	cs = (column / 3) * 3;
	while (k < 9)
	{
		if (puzzle[row][k] == c || puzzle[k + 1][column] == c)
			return (0);
		if (puzzle[rs + (k % 3)][cs + (k / 3)] == c)
			return (0);
		k++;
	}
	return (1);
}

int		fill_sudoku(char **puzzle, int row, int column)
{
	char	nb;

	nb = '1';
	if (row == 10)
		return (1);
	if (puzzle[row][column] != '.')
	{
		if (column == 8)
		{
			if (fill_sudoku(puzzle, row + 1, 0))
				return (1);
		}
		else
		{
			if (fill_sudoku(puzzle, row, column + 1))
				return (1);
		}
		return (0);
	}
	while (nb <= '9')
	{
		if (ft_check(puzzle, nb, row, column))
		{
			puzzle[row][column] = nb;
			if (column == 8)
			{
				if (fill_sudoku(puzzle, row + 1, 0))
					return (1);
			}
			else
			{
				if (fill_sudoku(puzzle, row, column + 1))
					return (1);
			}
			puzzle[row][column] = '.';
		}
		nb++;
	}
	return (0);
}
