/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/24 22:18:33 by hbennard          #+#    #+#             */
/*   Updated: 2018/10/24 22:23:31 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <string.h>

int	ft_strcmp(char *s1, char *s2)
{
	int i;

	i = 0;
	while (s1[i] != '\0' && s2[i] != '\0')
	{
		if (s1[i] != s2[i])
		{
			return (s1[i] - s2[i]);
			printf("%d", (s1[i] - s2[i]));
		}
		else
			i = i + 1;
	}
		if ((s1[i] != '\0' && s2[i] == '\0') || (s1[i] == '\0' && s2[i] != '\0'))
		{
			return (s1[i] - s2[i]);
			printf("%d", (s1[i] - s2[i]));
		}
		return (0);

}

int main (int argc, char **argv)
{
	printf("%d\n", ft_strcmp(argv[1], argv[2]));
	printf("%d", strcmp(argv[1], argv[2]));
	return (0);
}
