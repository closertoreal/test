/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colee_2.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mskiles <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/04 03:23:05 by mskiles           #+#    #+#             */
/*   Updated: 2018/11/04 23:06:41 by mskiles          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../header/ft_list.h"

int		find_cols(char *s)
{
	int i;

	i = 0;
	while (s[i] != '\n')
		i++;
	return (i);
}

int		find_rows(char *s)
{
	int i;
	int row;

	i = 0;
	row = 0;
	while (s[i])
	{
		if (s[i] == '\n')
			row++;
		i++;
	}
	return (row - 1);
}

void	print_res(char *s, int nb)
{
	ft_putstr("[rush-0");
	ft_putnbr(nb);
	ft_putstr("] [");
	ft_putnbr(find_cols(s));
	ft_putstr("] [");
	ft_putnbr(find_rows(s));
	ft_putstr("]\n");
}

void	compare(char *s)
{
	if (s[0] == '\n' && s[1] == '\0')
	{
		ft_putstr("[rush-00] [0] [0] || [rush-01] [0] [0] || [rush-02] ");
		ft_putstr("[0] [0] || [rush-03] [0] [0] || [rush-04] [0] [0]");
		return ;
	}
	else if (s[0] == 'A' && s[1] == '\n' && s[3] == '\0')
	{
		ft_putstr("[rush-02] [1] [1] || [rush-03] [1] [1] ||");
		ft_putstr(" [rush-04] [1] [1]");
		return ;
	}
	else if (ft_strcmp(rush00(find_cols(s), find_rows(s)), s) == 0)
		print_res(s, 0);
	else if (ft_strcmp(rush01(find_cols(s), find_rows(s)), s) == 0)
		print_res(s, 1);
	else if (ft_strcmp(rush02(find_cols(s), find_rows(s)), s) == 0)
		print_res(s, 2);
	else if (ft_strcmp(rush03(find_cols(s), find_rows(s)), s) == 0)
		print_res(s, 3);
	else if (ft_strcmp(rush04(find_cols(s), find_rows(s)), s) == 0)
		print_res(s, 4);
	else
		ft_putstr("not valid");
}
