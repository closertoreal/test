/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mskiles <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/03 19:25:07 by mskiles           #+#    #+#             */
/*   Updated: 2018/11/04 23:03:06 by mskiles          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_LIST_H
# define FT_LIST_H

# include <stdlib.h>
# include <stdio.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>
# include <unistd.h>

void		compare(char *s);
void		ft_putchar(char c);
void		ft_putstr(char *s);
char		*rush00(int x, int y);
char		*rush01(int x, int y);
char		*rush02(int x, int y);
char		*rush03(int x, int y);
char		*rush04(int x, int y);
int			ft_atoi(char *str);
char		*add_to_line(char *line, int x, char *chars);
int			ft_strcmp(char *s1, char *s2);
void		ft_putnbr(int nb);

#endif
