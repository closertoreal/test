/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mskiles <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/03 19:22:05 by mskiles           #+#    #+#             */
/*   Updated: 2018/11/04 23:02:22 by mskiles          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./header/ft_list.h"

int		main(void)
{
	int		fd;
	int		chunk;
	char	buf[30001];
	char	*string;
	int		i;

	chunk = read(0, buf, 30001);
	buf[chunk] = '\0';
	compare(buf);
	return (0);
}
