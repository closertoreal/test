/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sudoku.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: srolland <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/28 15:26:06 by srolland          #+#    #+#             */
/*   Updated: 2018/10/28 20:33:15 by ujyzene          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#define NR(col, row) (col / 8) == 0 ? row : row + 1

int		ft_check(char **puzzle, char c, int row, int col)
{
	int		k;

	k = 0;
	while (k < 9)
	{
		if (puzzle[row][k] == c || puzzle[k + 1][col] == c)
			return (0);
		if (puzzle[row - row % 3 + row % 9][col - col % 3 + col % 9] == c)
			return (0);
		k++;
	}
	return (1);
}

int		fill_sudoku(char **puzzle, int row, int column)
{
	char	nb;

	nb = '1';
	if (row == 10)
		return (1);
	if (puzzle[row][column] != '.')
	{
		if (fill_sudoku(puzzle, NR(column, row), (column + 1) % 9))
			return (1);
		return (0);
	}
	while (nb <= '9')
	{
		if (ft_check(puzzle, nb, row, column))
		{
			puzzle[row][column] = nb;
			if (fill_sudoku(puzzle, NR(column, row), (column + 1) % 9))
				return (1);
			puzzle[row][column] = '.';
		}
		nb++;
	}
	return (0);
}
