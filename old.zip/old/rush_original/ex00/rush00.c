#include <unistd.h>
#include <stdio.h>

int rush(int x, int y)
{
    int i;
    int j;
    
    i = 0;
    while (++i <= y)
    {
        j = 0;
            while (++j <= x)
                {
                        if ((j == 1 || j == x) && (i == 1 || i == y))
                            putchar('o');
                        else if (j == 1 || j == x)
                        putchar('|');
                        else if (i <= y)
                            putchar('-');
                    else
                        putchar(' ');
                }
        putchar('\n');
    }
    return (0);
}

int main(void)
{
    int x;
    int y;
    write(1, "Enter length: \n", 14);
    scanf("%d", &x);
    write(1, "Enter width: ", 14);
    scanf("%d", &y);
    rush(x,y);
}
	
