/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/21 22:30:46 by hbennard          #+#    #+#             */
/*   Updated: 2018/10/21 22:46:41 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_putchar(char c);

int	rush(int x, int y)
{
	int	i;
	int	j;

	i = 0;
	if (x < 0 || y < 0)
		return (0);
	else
		while (++i <= y)
	{
		j = 0;
		while (++j <= x)
		{
			if ((j == 1 && i == 1) || (i == y && j == x))
				ft_putchar('A');
			else if ((j == x && i == 1) || (j == 1 && i == y))
				ft_putchar('C');
			else if (j == 1 || i == y || i == 1 || j == x)
				ft_putchar('B');
			else
				ft_putchar(' ');
		}
		ft_putchar('\n');
	}
	return (0);
}
