/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/27 17:39:46 by hbennard          #+#    #+#             */
/*   Updated: 2018/10/27 17:42:54 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#define N 9;

int solve(**grid)
{
    int = i;
    row = 0;
    
    while (row != N)
    {
        col = 0;
        while (col != N)
        {
            if (grid[row][col] == '.')
            {
                while (num != N)
                {
                    if ((row-free(**grid, int num, char value) && col-free(**grid, int num, char value) && box-free(**grid, int num, char value))
                        grid[row][col] = num;
                        solve(**grid);
                        else
                        num++;
                }
            }
            col++;
            }
        row++;
    }
}
