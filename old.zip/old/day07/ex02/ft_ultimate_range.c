/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/25 19:42:43 by hbennard          #+#    #+#             */
/*   Updated: 2018/10/25 23:27:29 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_ultimate_range(int **range, int min, int max)
{
	int i;
	int size;

	if (min >= max)
	{
		return (0);
	}
	i = 1;
	size = max - min;
	range = (int**)malloc(sizeof(int) * size);
	if (!(range[0] == 0))
	{
		return (0);
	}
	range[0][0] = min;
	while (i < size)
	{
		range[i] = range[i - 1] + 1;
		i = i + 1;
	}
	return (size);
}
