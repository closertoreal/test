/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/25 17:03:02 by hbennard          #+#    #+#             */
/*   Updated: 2018/10/25 22:12:19 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_strdup(char *src)
{
	int		i;
	int		j;
	int		size;
	char	*srccpy;

	size = 0;
	j = 0;
	i = 0;
	while (src[i] != '\0')
	{
		size = size + 1;
		i = i + 1;
	}
	size = size + 1;
	srccpy = (char*)malloc(sizeof(char) * size);
	while (src[j] != '\0')
	{
		srccpy[j] = src[j];
		j = j + 1;
	}
	srccpy[j] = '\0';
	return (srccpy);
}
