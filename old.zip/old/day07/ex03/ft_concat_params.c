/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_concat_params.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/25 20:15:41 by hbennard          #+#    #+#             */
/*   Updated: 2018/10/25 22:14:00 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char		*ft_concat_params(int argc, char **argv)
{
	char	*params;
	int		i;
	int		count;

	i = 0;
	count = argc;
	params = (char*)malloc(sizeof(char) * argc);
	while (count != 0)
	{
		params[i] = argv[i];
		params[i + 1] = '\n';
		count = count - 1;
		i = i + 1;
	}
	return (params);
}
