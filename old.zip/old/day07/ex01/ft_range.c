/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/25 18:30:53 by hbennard          #+#    #+#             */
/*   Updated: 2018/10/25 22:47:46 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int i;
	int size;
	int *range;

	if (min >= max)
	{
		return (0);
	}
	i = 1;
	size = max - min;
	range = (int*)malloc(sizeof(int) * size);
	range[0] = min;
	while (i < size)
	{
		range[i] = range[i - 1] + 1;
		i = i + 1;
	}
	return (range);
}
