/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colee_2.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mskiles <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/04 03:23:05 by mskiles           #+#    #+#             */
/*   Updated: 2018/11/04 21:22:41 by mskiles          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../header/ft_list.h"

int     find_cols(char *s)
{
	int i;

	i = 0;
	while (s[i] != '\n')
		i++;
	return (i);
}

int		find_rows(char *s)
{
	int i;
	int row;

	i = 0;
	row = 0;
	while (s[i])
	{
		if (s[i] == '\n')
			row++;
		i++;
	}
	return (row - 1);
}

void	compare(char *s)
{
	int res;

	res = ft_strcmp(rush01(find_cols(s), find_rows(s)), s);
	ft_putnbr(res);
	if (res == 0)
	{
		ft_putstr("[rush-00] [");
		ft_putnbr(find_cols(s));
		ft_putstr("] [");
		ft_putnbr(find_rows(s));
		ft_putstr("]\n");
	}
    printf("cols = %d\nrows = %d\n", find_cols(s), find_rows(s));
    printf("%s", rush01(find_cols(s), find_rows(s)));
}
