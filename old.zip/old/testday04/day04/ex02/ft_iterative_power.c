/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/20 18:30:53 by hbennard          #+#    #+#             */
/*   Updated: 2018/10/20 19:41:08 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int i;
	int result;

	i = 2;
	result = nb;
	if (power < 0)
	{
		return (0);
	}
	if (power == 0)
	{
		result = 1;
		return (result);
	}
	if (power == 1)
	{
		return (result);
	}
	while (i <= power)
	{
		result = nb * result;
		i = i + 1;
	}
	return (result);
}
