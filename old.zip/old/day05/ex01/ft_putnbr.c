/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/22 19:07:14 by hbennard          #+#    #+#             */
/*   Updated: 2018/10/23 15:47:48 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar (char c);

void	ft_putnbr(int nb)
{
	int swap;

	swap = nb;
	if (swap < 0)
	{
		ft_putchar('-');
		swap = -swap;
	}
	if (swap / 10 != 0)
	{
		ft_putnbr(swap / 10);
	}
	ft_putchar(swap % 10 + 48);
}
