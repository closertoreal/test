/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/23 16:39:20 by hbennard          #+#    #+#             */
/*   Updated: 2018/10/23 22:00:10 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_atoi(char *str)
{
	int		index;
	int		result;

	index = 0;
	result = 0;
	while (str[index] != '\0')
	{
		if ((char)(str[index]) >= 48 && (char)(str[index]) <= 57)
		{
			result = result * 10 + (char)(str[index] - 48);
			index = index + 1;
		}
		else if ((char)(str[index]) == '/t' || (char)(str[index]) == '/r'
				|| (char)(str[index]) == '/n' || (char)(str[index]) == '/v'
				|| (char)(str[index]) == '/f' || (char)(str[index]) == '+'
				|| (char)(str[index]) == '-' || (char)(str[index] == ' '))
		{
			index = index + 1;
		}
	}
	return (result);
}
