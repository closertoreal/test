/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/22 15:28:22 by hbennard          #+#    #+#             */
/*   Updated: 2018/11/22 15:37:46 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_sqrt(int nb)
{
	int root;
	int result;
	int i;

	i = 2;
	result = 0;
	root = 0;
	if (nb <= 0)
	{
		return (0);
	}
	while (i <= nb)
	{
		root = i * i;
		if (root == nb)
		{
			result = i;
			return (result);
		}
		i++;
	}
	return (result);
}
