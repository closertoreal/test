/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbennard <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/20 19:48:27 by hbennard          #+#    #+#             */
/*   Updated: 2018/11/22 15:36:35 by hbennard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_recursive_factorial(int nb)
{
	int result;

	result = 1;
	if (nb == 1)
	{
		return (1);
	}
	else
	{
		result = ft_recursive_factorial(nb - 1) * nb;
	}
	return (result);
}
