find ./ -name "*.sh" | rev | cat -d / -f 1 | cat -c4- | rev
