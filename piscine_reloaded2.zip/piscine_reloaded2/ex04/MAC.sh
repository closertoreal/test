ifconfig | grep "ether " | cut -c8-
